from datetime import datetime, timedelta
from stay_signal_detector import WARNING_STAY, DANGER_STAY


def check_stay_alert(entry_time, current_time):
    elapsed = (current_time - entry_time).total_seconds()

    if elapsed >= DANGER_STAY:
        return "위험"
    elif elapsed >= WARNING_STAY:
        return "주의"
    else:
        return "정상"


def test_stay_alert():
    entry_time = datetime.now().astimezone()

    test_cases = [
        (0, "정상"),
        (29, "정상"),
        (30, "주의"),
        (59, "주의"),
        (60, "위험"),
    ]

    print("===== 추정 체류 경보 테스트 =====")
    print(f"주의 기준: {WARNING_STAY}초")
    print(f"위험 기준: {DANGER_STAY}초\n")

    for seconds, expected in test_cases:
        current_time = entry_time + timedelta(seconds=seconds)
        result = check_stay_alert(entry_time, current_time)

        status = "PASS" if result == expected else "FAIL"

        print(
            f"경과 시간: {seconds:2d}초 | "
            f"예상: {expected} | "
            f"실제: {result} | "
            f"{status}"
        )


if __name__ == "__main__":
    test_stay_alert()