
import time

from stay_signal_detector import (
    SIGNAL_COUNT,
    MAX_MESSAGE_GAP,
    STALE_TIMEOUT,
    WARNING_STAY,
    DANGER_STAY,
    is_weak_signal,
    is_good_signal,
)

# PC 시뮬레이션 설정
WORKER_ID = "worker_01"
TEST_DURATION = 125
MESSAGE_INTERVAL = 1


class WorkerMonitor:
    def __init__(self, worker_id):
        self.worker_id = worker_id

        self.state = "normal"
        self.weak_count = 0
        self.good_count = 0

        self.entry_time = None
        self.last_received = None

        self.warning_sent = False
        self.danger_sent = False
        self.communication_lost = False

        # 메시지 간격 확인용
        self.previous_message_time = None

    def receive(self, rssi, snr, now):
        # 통신 두절 이후 메시지가 다시 수신된 경우
        if self.communication_lost:
            print(f"\n[{self.worker_id}] 통신 복구")
            print(
                "※ 통신 복구만으로 실제 위치나 "
                "안전 상태는 확인되지 않습니다.\n"
            )
            self.communication_lost = False

        # 메시지 간격이 길면 연속 신호 판정을 초기화
        if self.previous_message_time is not None:
            gap = now - self.previous_message_time

            if gap > MAX_MESSAGE_GAP or gap < 0:
                self.weak_count = 0
                self.good_count = 0

        self.last_received = now
        self.previous_message_time = now

        # RSSI·SNR 기반 신호 분류
        if is_weak_signal(rssi, snr):
            self.weak_count += 1
            self.good_count = 0

        elif is_good_signal(rssi, snr):
            self.good_count += 1
            self.weak_count = 0

        else:
            self.weak_count = 0
            self.good_count = 0

        print(
            f"[수신] {self.worker_id} | "
            f"RSSI={rssi} dBm | SNR={snr} dB"
        )

        # 진입 추정
        if (
            self.state == "normal"
            and self.weak_count >= SIGNAL_COUNT
        ):
            self.state = "entry_suspected"
            self.entry_time = now

            self.weak_count = 0
            self.warning_sent = False
            self.danger_sent = False

            print(f"\n[{self.worker_id}] 진입 추정")
            print("추정 체류 타이머 시작\n")

        # 이탈 추정
        elif (
            self.state == "entry_suspected"
            and self.good_count >= SIGNAL_COUNT
        ):
            self.state = "exit_suspected"
            self.good_count = 0

            print(f"\n[{self.worker_id}] 이탈 추정")
            print("추정 체류 구간 종료")
            print("※ 실제 퇴실 여부는 미확인\n")

        # 재진입 추정
        elif (
            self.state == "exit_suspected"
            and self.weak_count >= SIGNAL_COUNT
        ):
            self.state = "entry_suspected"
            self.entry_time = now

            self.weak_count = 0
            self.warning_sent = False
            self.danger_sent = False

            print(f"\n[{self.worker_id}] 재진입 추정")
            print("새 추정 체류 타이머 시작\n")

    def check(self, now):
        if self.last_received is None:
            return

        communication_gap = now - self.last_received

        # 10초 초과 통신 두절 감지
        if communication_gap > STALE_TIMEOUT:
            if not self.communication_lost:
                self.communication_lost = True

                print(f"\n[{self.worker_id}] 통신 두절 경보")
                print(
                    f"마지막 수신 후 "
                    f"{communication_gap:.1f}초 경과"
                )
                print("현재 체류 상태: 불확실")
                print("작업자 상태 확인 필요\n")

        # 통신 두절 시 기존 추정 상태 및 경보 기록 보존
        if self.communication_lost:
            return

        # 진입 추정 상태일 때만 체류 시간 검사
        if (
            self.state != "entry_suspected"
            or self.entry_time is None
        ):
            return

        elapsed = now - self.entry_time

        # 60초 위험 경보
        if elapsed >= DANGER_STAY and not self.danger_sent:
            self.danger_sent = True

            print(f"\n[{self.worker_id}] 추정 체류 위험 경보")
            print(f"진입 추정 후 {elapsed:.1f}초 경과")
            print("작업자 상태 확인 필요\n")

        # 30초 주의 경보
        elif elapsed >= WARNING_STAY and not self.warning_sent:
            self.warning_sent = True

            print(f"\n[{self.worker_id}] 추정 체류 주의 경보")
            print(f"진입 추정 후 {elapsed:.1f}초 경과\n")


def simulated_signal(seconds):
    """
    PC 가상 신호 시나리오

    0~3초: 정상 신호
    3~75초: 약한 신호
    75~90초: 통신 중단 (15초)
    90~105초: 약한 신호 복구
    105초 이후: 양호한 신호
    """

    if seconds < 3:
        return -65, 8.0

    if seconds < 75:
        return -100, -5.0

    if seconds < 90:
        return None

    if seconds < 105:
        return -100, -5.0

    return -60, 9.0


def run_simulation():
    monitors = {
        WORKER_ID: WorkerMonitor(WORKER_ID)
    }

    start_time = time.monotonic()

    print("===== 통합 안전 모니터링 시뮬레이션 =====")
    print(f"작업자: {WORKER_ID}")
    print(f"주의: {WARNING_STAY}초")
    print(f"위험: {DANGER_STAY}초")
    print(f"통신 두절: {STALE_TIMEOUT}초 초과")
    print("통신 중단 시나리오: 75~90초 (15초)")
    print("※ 실제 T1000-E 통신이 아닌 PC 가상 데이터입니다.\n")

    try:
        while True:
            elapsed = time.monotonic() - start_time

            if elapsed >= TEST_DURATION:
                print("\n===== 통합 테스트 종료 =====")
                break

            now = time.monotonic()
            signal = simulated_signal(elapsed)

            if signal is None:
                print(f"[미수신] {WORKER_ID}")

            else:
                rssi, snr = signal
                monitors[WORKER_ID].receive(rssi, snr, now)

            # 작업자별 체류 및 통신 상태 확인
            for monitor in monitors.values():
                monitor.check(now)

            time.sleep(MESSAGE_INTERVAL)

    except KeyboardInterrupt:
        print("\n사용자가 테스트를 종료했습니다.")


if __name__ == "__main__":
    run_simulation()
