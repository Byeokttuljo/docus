#pragma once

void setupWorkerHeartbeat();