
import csv
from datetime import datetime
from pathlib import Path

# CSV 파일 위치
BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "communication_log.csv"



def classify_signal(rssi, snr):
    """가상 테스트용 통신 신호 상태 분류"""

    if rssi <= -95 or snr < 0:
        return "신호 약화"

    if rssi <= -85 or snr < 3:
        return "주의"

    return "양호"



def calculate_weak_signal_duration(messages):
    """연속된 신호 약화 구간의 기록 간 시간 차이 계산"""

    weak_start = None

    print("\n[신호 약화 지속 시간 분석]")

    for msg in messages:
        timestamp = datetime.fromisoformat(msg["timestamp"])
        rssi = float(msg["rssi_dbm"])
        snr = float(msg["snr_db"])

        status = classify_signal(rssi, snr)

        if status == "신호 약화":
            if weak_start is None:
                weak_start = timestamp

        else:
            if weak_start is not None:
                duration = (timestamp - weak_start).total_seconds()

                print(f"신호 약화 시작: {weak_start}")
                print(f"다음 상태 변화까지: {duration:.1f}초")

                weak_start = None

    if weak_start is not None:
        print(f"신호 약화 시작: {weak_start}")
        print("마지막 기록까지 신호 약화 상태 (종료 시각 미확인)")




def analyze_communication():
    """작업자 1명의 RSSI, SNR 데이터 분석"""

    if not LOG_FILE.exists():
        print("오류: 통신 기록 파일이 없습니다.")
        return

    # CSV 데이터 읽기
    with open(LOG_FILE, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        messages = list(reader)

    if not messages:
        print("분석할 데이터가 없습니다.")
        return

    # RSSI, SNR 값 추출
    rssi_values = [float(msg["rssi_dbm"]) for msg in messages]
    snr_values = [float(msg["snr_db"]) for msg in messages]

    # 통계 계산
    avg_rssi = sum(rssi_values) / len(rssi_values)
    avg_snr = sum(snr_values) / len(snr_values)

    print("===== 통신 데이터 분석 결과 =====")
    print(f"작업자 ID: {messages[0]['worker_id']}")
    print(f"전체 메시지 수: {len(messages)}")

    print("\n[RSSI 분석]")
    print(f"평균 RSSI: {avg_rssi:.1f} dBm")
    print(f"최솟값: {min(rssi_values):.1f} dBm")
    print(f"최댓값: {max(rssi_values):.1f} dBm")

    print("\n[SNR 분석]")
    print(f"평균 SNR: {avg_snr:.1f} dB")
    print(f"최솟값: {min(snr_values):.1f} dB")
    print(f"최댓값: {max(snr_values):.1f} dB")

    
    print("\n[시간별 통신 기록 및 상태]")
    for msg in messages:
        rssi = float(msg["rssi_dbm"])
        snr = float(msg["snr_db"])

        # 통신 상태 분류
        status = classify_signal(rssi, snr)

        print(
            f"{msg['timestamp']} | "
            f"RSSI={rssi:.1f} dBm | "
            f"SNR={snr:.1f} dB | "
            f"상태={status}"
        )
    calculate_weak_signal_duration(messages)


if __name__ == "__main__":
    analyze_communication()
