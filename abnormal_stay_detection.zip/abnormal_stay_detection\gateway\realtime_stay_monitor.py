
import time
from datetime import datetime

from stay_signal_detector import (
    WEAK_RSSI,
    WEAK_SNR,
    GOOD_RSSI,
    GOOD_SNR,
    SIGNAL_COUNT,
    MAX_MESSAGE_GAP,
    STALE_TIMEOUT,
    WARNING_STAY,
    DANGER_STAY,
    is_weak_signal,
    is_good_signal,
)

WORKER_ID = "worker_01"
MESSAGE_INTERVAL = 1

# 처음 3초는 정상 신호, 이후 약한 신호 유지
# 75초가 지나면 양호한 신호로 전환
TEST_DURATION = 85


def simulated_signal(seconds):
    if seconds < 3:
        return -65, 8.0
    elif seconds < 75:
        return -100, -5.0
    else:
        return -60, 9.0


def run_monitor():
    state = "normal"
    weak_count = 0
    good_count = 0

    entry_time = None
    previous_message_time = None
    last_received_time = None

    warning_sent = False
    danger_sent = False

    start_time = time.monotonic()

    print("===== RSSI·SNR 실시간 시뮬레이션 =====")
    print(f"작업자: {WORKER_ID}")
    print(f"주의 기준: {WARNING_STAY}초")
    print(f"위험 기준: {DANGER_STAY}초")
    print(f"통신 두절 기준: {STALE_TIMEOUT}초")
    print("※ 실제 LoRa 측정값이 아닌 가상 신호입니다.")
    print("※ 테스트 중 Ctrl+C를 누르면 종료됩니다.\n")

    try:
        while True:
            elapsed_test = time.monotonic() - start_time

            if elapsed_test >= TEST_DURATION:
                print("\n===== 테스트 종료 =====")
                break

            now = datetime.now().astimezone()
            rssi, snr = simulated_signal(elapsed_test)

            # 가상 메시지 수신
            last_received_time = now

            if previous_message_time is not None:
                gap = (now - previous_message_time).total_seconds()

                if gap > MAX_MESSAGE_GAP or gap < 0:
                    weak_count = 0
                    good_count = 0

            if is_weak_signal(rssi, snr):
                weak_count += 1
                good_count = 0

            elif is_good_signal(rssi, snr):
                good_count += 1
                weak_count = 0

            else:
                weak_count = 0
                good_count = 0

            print(
                f"[수신] {now.strftime('%H:%M:%S')} | "
                f"{WORKER_ID} | RSSI={rssi} dBm | "
                f"SNR={snr} dB"
            )

            if state == "normal" and weak_count >= SIGNAL_COUNT:
                state = "entry_suspected"
                entry_time = time.monotonic()

                weak_count = 0
                warning_sent = False
                danger_sent = False

                print("\n[진입 추정] 약한 신호 3회 연속 감지")
                print("[타이머] 추정 체류 시간 측정 시작\n")

            elif (
                state == "entry_suspected"
                and good_count >= SIGNAL_COUNT
            ):
                state = "exit_suspected"
                good_count = 0

                print("\n[이탈 추정] 양호한 신호 3회 연속 감지")
                print("[타이머] 해당 추정 체류 구간 종료")
                print("[안내] 실제 퇴실 여부는 미확인\n")

            elif (
                state == "exit_suspected"
                and weak_count >= SIGNAL_COUNT
            ):
                state = "entry_suspected"
                entry_time = time.monotonic()

                weak_count = 0
                warning_sent = False
                danger_sent = False

                print("\n[재진입 추정] 약한 신호 3회 연속 감지")
                print("[타이머] 새 추정 체류 구간 시작\n")

            # 진입 추정 상태에서 경보 시간 확인
            if state == "entry_suspected" and entry_time is not None:
                stay_elapsed = time.monotonic() - entry_time

                if stay_elapsed >= DANGER_STAY and not danger_sent:
                    danger_sent = True
                    print(
                        f"\n[위험 경보] 추정 체류 "
                        f"{stay_elapsed:.1f}초 경과"
                    )
                    print("작업자 상태 확인 필요\n")

                elif stay_elapsed >= WARNING_STAY and not warning_sent:
                    warning_sent = True
                    print(
                        f"\n[주의 경보] 추정 체류 "
                        f"{stay_elapsed:.1f}초 경과"
                    )
                    print("작업자 상태 확인 권장\n")

            # 통신 상태 확인
            if last_received_time is not None:
                communication_gap = (
                    datetime.now().astimezone() - last_received_time
                ).total_seconds()

                if communication_gap > STALE_TIMEOUT:
                    print("\n[통신 경보] 메시지 수신 중단")
                    print("현재 체류 상태: 불확실\n")

            previous_message_time = now
            time.sleep(MESSAGE_INTERVAL)

    except KeyboardInterrupt:
        print("\n사용자가 테스트를 종료했습니다.")


if __name__ == "__main__":
    run_monitor()
