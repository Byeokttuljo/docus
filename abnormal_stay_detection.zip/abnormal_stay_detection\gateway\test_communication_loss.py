
import time
from datetime import datetime

from stay_signal_detector import STALE_TIMEOUT

WORKER_ID = "worker_01"

# 테스트 시나리오
RECEIVE_UNTIL = 5
RESUME_AT = 17
TEST_DURATION = 21


def run_test():
    start_time = time.monotonic()
    last_received = None
    communication_lost = False

    print("===== 통신 두절 시뮬레이션 =====")
    print(f"작업자: {WORKER_ID}")
    print(f"통신 두절 기준: {STALE_TIMEOUT}초")
    print("※ PC에서 생성한 가상 통신 데이터입니다.\n")

    try:
        while True:
            elapsed = time.monotonic() - start_time

            if elapsed >= TEST_DURATION:
                print("\n===== 테스트 종료 =====")
                break

            # 0~5초: 수신 / 5~17초: 중단 / 17초 이후: 복구
            receiving = elapsed < RECEIVE_UNTIL or elapsed >= RESUME_AT

            if receiving:
                now = time.monotonic()
                last_received = now

                if communication_lost:
                    print(
                        "\n[통신 복구] 메시지 수신 재개"
                    )
                    print(
                        "※ 통신 복구만으로 실제 위치나 "
                        "안전 상태가 확인되지는 않습니다.\n"
                    )
                    communication_lost = False

                print(
                    f"[수신] {datetime.now().strftime('%H:%M:%S')} | "
                    f"{WORKER_ID}"
                )

            elif last_received is not None:
                gap = time.monotonic() - last_received

                print(
                    f"[미수신] 마지막 수신 후 {gap:.1f}초"
                )

                if gap > STALE_TIMEOUT and not communication_lost:
                    communication_lost = True

                    print("\n[통신 두절 경보]")
                    print(
                        f"마지막 수신 후 {gap:.1f}초 경과"
                    )
                    print("현재 체류 상태: 불확실")
                    print("조치: 통신 및 작업자 상태 확인 필요\n")

            time.sleep(1)

    except KeyboardInterrupt:
        print("\n사용자가 테스트를 종료했습니다.")


if __name__ == "__main__":
    run_test()
