#include "SinglePortModule.h"
#include "MeshService.h"
#include "Channels.h"
#include "main.h"

#include <Arduino.h>
#include <cstdio>
#include <cstring>

class WorkerHeartbeatThread : public SinglePortModule,
                              private concurrency::OSThread {
private:
    static constexpr uint32_t HEARTBEAT_INTERVAL_MS = 5000;

    void sendHeartbeat()
    {
        // 기본 공개 채널로 작업자 정보를 송신하지 않음
        if (channels.isDefaultChannel(0)) {
            Serial.println("[WorkerHeartbeat] Private channel required");
            return;
        }

        const char *message =
            "{\"type\":\"HEARTBEAT\"}";

        meshtastic_MeshPacket *p = allocDataPacket();

        if (!p) {
            Serial.println("[WorkerHeartbeat] Packet allocation failed");
            return;
        }

        size_t length = strlen(message);

        if (length > sizeof(p->decoded.payload.bytes)) {
            packetPool.release(p);
            return;
        }

        p->to = NODENUM_BROADCAST;
        p->channel = channels.getPrimaryIndex();
        p->want_ack = false;
        p->decoded.payload.size = length;

        memcpy(
            p->decoded.payload.bytes,
            message,
            length
        );

        ErrorCode result = service->sendToMesh(p);

        if (result == ERRNO_OK || result == ERRNO_SHOULD_RELEASE) {
            Serial.println("[WorkerHeartbeat] Heartbeat queued");
        } else {
            Serial.println("[WorkerHeartbeat] Send failed");
        }
    }

protected:
    int32_t runOnce() override
    {
        sendHeartbeat();
        return HEARTBEAT_INTERVAL_MS;
    }

public:
    WorkerHeartbeatThread()
        : SinglePortModule(
              "WorkerHeartbeat",
              meshtastic_PortNum_TEXT_MESSAGE_APP
          ),
          concurrency::OSThread("WorkerHeartbeat")
    {
    }
};

void setupWorkerHeartbeat()
{
    new WorkerHeartbeatThread();
}