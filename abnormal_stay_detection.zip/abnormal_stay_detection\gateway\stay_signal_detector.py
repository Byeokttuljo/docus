
import csv
from datetime import datetime, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "communication_log.csv"

# RSSI·SNR 기준 (시뮬레이션용)
WEAK_RSSI = -95
WEAK_SNR = 0
GOOD_RSSI = -85
GOOD_SNR = 3

SIGNAL_COUNT = 3
MAX_MESSAGE_GAP = 5
STALE_TIMEOUT = 10

# 추정 체류 경보 기준 (단축 테스트용)
WARNING_STAY = 30
DANGER_STAY = 60


def load_signal_data():
    if not LOG_FILE.exists():
        print("통신 기록 파일이 없습니다.")
        return []

    with open(LOG_FILE, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def is_weak_signal(rssi, snr):
    return rssi <= WEAK_RSSI or snr < WEAK_SNR


def is_good_signal(rssi, snr):
    return rssi > GOOD_RSSI and snr >= GOOD_SNR


def detect_signal_events(messages):
    events = []
    states = {}

    sorted_messages = sorted(
        messages,
        key=lambda m: datetime.fromisoformat(m["timestamp"])
    )

    for msg in sorted_messages:
        worker_id = msg["worker_id"]
        current_time = datetime.fromisoformat(msg["timestamp"])
        rssi = float(msg["rssi_dbm"])
        snr = float(msg["snr_db"])

        if worker_id not in states:
            states[worker_id] = {
                "state": "normal",
                "weak_count": 0,
                "good_count": 0,
                "previous_time": None,
                "entry_time": None,
            }

        worker = states[worker_id]
        previous_time = worker["previous_time"]

        if previous_time is not None:
            gap = (current_time - previous_time).total_seconds()

            if gap > MAX_MESSAGE_GAP or gap < 0:
                worker["weak_count"] = 0
                worker["good_count"] = 0

        if is_weak_signal(rssi, snr):
            worker["weak_count"] += 1
            worker["good_count"] = 0

        elif is_good_signal(rssi, snr):
            worker["good_count"] += 1
            worker["weak_count"] = 0

        else:
            worker["weak_count"] = 0
            worker["good_count"] = 0

        if (
            worker["state"] == "normal"
            and worker["weak_count"] >= SIGNAL_COUNT
        ):
            worker["state"] = "entry_suspected"
            worker["entry_time"] = current_time
            worker["weak_count"] = 0

            events.append({
                "worker_id": worker_id,
                "event": "진입 추정",
                "timestamp": current_time,
            })

        elif (
            worker["state"] == "entry_suspected"
            and worker["good_count"] >= SIGNAL_COUNT
        ):
            worker["state"] = "exit_suspected"
            worker["good_count"] = 0

            elapsed = (
                current_time - worker["entry_time"]
            ).total_seconds()

            events.append({
                "worker_id": worker_id,
                "event": "이탈 추정",
                "timestamp": current_time,
                "elapsed": elapsed,
            })

        elif (
            worker["state"] == "exit_suspected"
            and worker["weak_count"] >= SIGNAL_COUNT
        ):
            worker["state"] = "entry_suspected"
            worker["entry_time"] = current_time
            worker["weak_count"] = 0

            events.append({
                "worker_id": worker_id,
                "event": "재진입 추정",
                "timestamp": current_time,
            })

        worker["previous_time"] = current_time

    return events


def analyze_worker_status(events, messages):
    if not messages:
        print("분석할 통신 데이터가 없습니다.")
        return

    now = datetime.now().astimezone()

    worker_ids = sorted(set(
        msg["worker_id"] for msg in messages
    ))

    for worker_id in worker_ids:
        worker_messages = [
            msg for msg in messages
            if msg["worker_id"] == worker_id
        ]

        worker_events = [
            event for event in events
            if event["worker_id"] == worker_id
        ]

        last_received = max(
            datetime.fromisoformat(msg["timestamp"])
            for msg in worker_messages
        )

        since_received = (
            now - last_received
        ).total_seconds()

        print(f"\n===== {worker_id} 현재 상태 =====")
        print(f"마지막 수신: {last_received}")

        if since_received > STALE_TIMEOUT:
            print("통신 상태: 기록 만료 / 통신 두절 확인 필요")
            print("현재 체류 상태: 불확실")

            if worker_events:
                print(
                    f"마지막 추정 이벤트: "
                    f"{worker_events[-1]['event']}"
                )

            print("조치: 작업자 상태 확인 필요")
            continue

        print("통신 상태: 최근 메시지 수신")

        if not worker_events:
            print("출입 상태: 진입 추정 기록 없음")
            return

        latest_event = worker_events[-1]

        if latest_event["event"] == "이탈 추정":
            print("출입 상태: 이탈 추정")
            print("실제 퇴실 여부: 미확인")
            print("추정 체류 타이머: 해당 구간 종료")
            print("안전 확인: 신호 회복만으로 확정 불가")
            continue

        entry_time = latest_event["timestamp"]
        elapsed = max(
            0,
            (now - entry_time).total_seconds()
        )

        print(f"출입 상태: {latest_event['event']}")
        print(f"최근 진입 추정 시각: {entry_time}")
        print(f"최근 진입 추정 이후 경과: {elapsed:.0f}초")

        if elapsed >= DANGER_STAY:
            print("추정 체류 경보: 위험 (60초 이상)")
        elif elapsed >= WARNING_STAY:
            print("추정 체류 경보: 주의 (30초 이상)")
        else:
            print("추정 체류 경보: 기준 시간 미만")

        print("※ 실제 진입 및 체류 여부는 확인되지 않았습니다.")


if __name__ == "__main__":
    messages = load_signal_data()

    print("===== RSSI·SNR 신호 데이터 =====")

    for msg in messages:
        print(
            f"시간: {msg['timestamp']} | "
            f"작업자: {msg['worker_id']} | "
            f"RSSI: {msg['rssi_dbm']} dBm | "
            f"SNR: {msg['snr_db']} dB"
        )

    print(f"\n총 {len(messages)}개의 메시지를 읽었습니다.")

    print("\n===== 진입·이탈 추정 이벤트 =====")

    events = detect_signal_events(messages)

    if not events:
        print("감지된 이벤트가 없습니다.")
    else:
        for i, event in enumerate(events, start=1):
            print(
                f"{i}. {event['worker_id']} | "
                f"{event['event']} | "
                f"{event['timestamp']}"
            )

            if "elapsed" in event:
                print(
                    f"   해당 구간 추정 경과: "
                    f"{event['elapsed']:.0f}초"
                )

        print(f"\n총 {len(events)}개 이벤트 감지")

    print("\n===== 현재 작업자 상태 분석 =====")
    analyze_worker_status(events, messages)
