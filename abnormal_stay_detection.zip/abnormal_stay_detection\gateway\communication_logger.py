
import csv
import time
from datetime import datetime
from pathlib import Path

# CSV 파일 저장 위치
BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "communication_log.csv"


def record_message(worker_id, node_id, rssi, snr):
    """작업자 1명의 통신 정보를 CSV에 기록"""

    # 현재 PC 시각 기록
    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")

    # 파일이 처음 만들어지는 경우 헤더 추가
    is_new_file = not LOG_FILE.exists() or LOG_FILE.stat().st_size == 0

    # CSV 파일에 데이터 추가
    encoding = "utf-8-sig" if is_new_file else "utf-8"

    with open(LOG_FILE, "a", newline="", encoding=encoding) as f:
        writer = csv.writer(f)

        if is_new_file:
            writer.writerow([
                "timestamp",
                "worker_id",
                "node_id",
                "rssi_dbm",
                "snr_db"
            ])

        writer.writerow([
            timestamp,
            worker_id,
            node_id,
            rssi,
            snr
        ])

    print(
        f"기록 완료: {worker_id} | "
        f"RSSI={rssi} dBm | SNR={snr} dB"
    )


# 작업자 1명의 가상 통신 데이터 5개
if __name__ == "__main__":

    test_messages = [
        (-60, 9.0),
        (-70, 6.0),
        (-96, -1.0),
        (-98, -3.0),
        (-100, -5.0)
    ]

    for rssi, snr in test_messages:
        record_message(
            worker_id="worker_01",
            node_id="!a1b2c301",
            rssi=rssi,
            snr=snr
        )

        # 다음 메시지 기록 전 1초 대기
        time.sleep(1)

    print("저장 파일:", LOG_FILE)
