
import json
from pathlib import Path

# workers.json 파일 읽기
BASE_DIR = Path(__file__).resolve().parent

with open(BASE_DIR / "workers.json", "r", encoding="utf-8") as f:
    workers = json.load(f)["workers"]

# 작업자 5명의 가상 수신 메시지
received_messages = [
    {
        "from": "!a1b2c301",
        "payload": {
            "event": "HIGH_TEMP_EXPOSURE",
            "state": "DANGER",
            "temperature_c": 36.0,
            "exposure_seconds": 60
        }
    },
    {
        "from": "!a1b2c302",
        "payload": {
            "event": "ABNORMAL_STAY",
            "state": "WARNING",
            "elapsed_seconds": 5
        }
    },
    {
        "from": "!a1b2c303",
        "payload": {
            "event": "HIGH_TEMP_EXPOSURE",
            "state": "CAUTION",
            "temperature_c": 31.0,
            "exposure_seconds": 600
        }
    },
    {
        "from": "!a1b2c304",
        "payload": {
            "event": "HIGH_TEMP_EXPOSURE",
            "state": "NORMAL",
            "temperature_c": 25.0,
            "exposure_seconds": 0
        }
    },
    {
        "from": "!a1b2c305",
        "payload": {
            "event": "ABNORMAL_STAY",
            "state": "DANGER",
            "elapsed_seconds": 10
        }
    }
]

print("=== 작업자 5명 게이트웨이 수신 테스트 ===")

for message in received_messages:
    node_id = message["from"]
    worker_id = workers.get(node_id, "UNKNOWN")
    payload = message["payload"]

    print()
    print("작업자:", worker_id)
    print("발신 노드:", node_id)
    print("이벤트:", payload["event"])
    print("상태:", payload["state"])

    if "temperature_c" in payload:
        print("온도:", payload["temperature_c"], "℃")

    if "exposure_seconds" in payload:
        print("노출 시간:", payload["exposure_seconds"], "초")

    if "elapsed_seconds" in payload:
        print("체류 시간:", payload["elapsed_seconds"], "초")

print()
print("총 수신 메시지:", len(received_messages))
