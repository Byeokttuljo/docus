
#include "high_temp_exposure.h"
#include <cassert>
#include <iostream>
#include <limits>

int main() {
    HighTempExposure detector(10, 5, 3);

    // 1. Normal temperature
    TempResult r = detector.update(28.0f, 0);
    assert(!r.sensorError);
    assert(!r.sensorErrorChanged);
    assert(r.state == TempState::NORMAL);
    std::cout << "[PASS] Normal sensor reading\n";

    // 2. Enter CAUTION state
    detector.update(31.0f, 1);
    detector.update(31.0f, 5);
    detector.update(31.0f, 9);
    r = detector.update(31.0f, 11);
    assert(r.state == TempState::CAUTION);
    std::cout << "[PASS] CAUTION state entered\n";

    // 3. NaN sensor error
    r = detector.update(
        std::numeric_limits<float>::quiet_NaN(), 12
    );
    assert(r.sensorError);
    assert(r.sensorErrorChanged);
    assert(r.state == TempState::CAUTION);
    assert(!r.stateChanged);
    std::cout << "[PASS] NaN detected, warning retained\n";

    // 4. Continued sensor error
    r = detector.update(
        std::numeric_limits<float>::infinity(), 13
    );
    assert(r.sensorError);
    assert(!r.sensorErrorChanged);
    assert(r.state == TempState::CAUTION);
    std::cout << "[PASS] Continuous sensor error handled\n";

    // 5. Sensor recovery with high temperature
    r = detector.update(36.0f, 14);
    assert(!r.sensorError);
    assert(r.sensorErrorChanged);
    assert(r.state == TempState::CAUTION);
    assert(r.exposureSeconds == 0);
    std::cout << "[PASS] Sensor recovered, timer restarted\n";

    // 6. DANGER after new continuous exposure
    r = detector.update(36.0f, 17);
    assert(r.state == TempState::DANGER);
    assert(r.stateChanged);
    std::cout << "[PASS] DANGER triggered after recovery\n";

    // 7. Out-of-range temperature
    r = detector.update(100.0f, 18);
    assert(r.sensorError);
    assert(r.sensorErrorChanged);
    assert(r.state == TempState::DANGER);
    std::cout << "[PASS] Out-of-range reading detected\n";

    // 8. Return to normal temperature
    r = detector.update(28.0f, 19);
    assert(!r.sensorError);
    assert(r.sensorErrorChanged);
    assert(r.state == TempState::DANGER);

    r = detector.update(28.0f, 24);
    assert(r.state == TempState::NORMAL);
    assert(r.stateChanged);
    std::cout << "[PASS] Normal recovery after 5 seconds\n";

    std::cout << "\nAll 8 sensor tests passed!\n";
    return 0;
}
