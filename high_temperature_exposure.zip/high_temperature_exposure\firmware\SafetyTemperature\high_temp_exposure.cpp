
#include "high_temp_exposure.h"
#include <cmath>

// Prototype sensor validation limits (not safety thresholds)
namespace {
constexpr float MIN_VALID_TEMP_C = -40.0f;
constexpr float MAX_VALID_TEMP_C = 85.0f;

// Maximum interval between valid temperature samples
constexpr uint32_t MAX_SAMPLE_GAP_SECONDS = 5;
}

HighTempExposure::HighTempExposure(
    uint32_t cautionSeconds,
    uint32_t warningSeconds,
    uint32_t dangerSeconds
)
    : currentState(TempState::NORMAL),
      currentTempZone(TempState::NORMAL),
      zoneStartSeconds(0),
      recoveryStartSeconds(0),
      isRecovering(false),
      cautionThreshold(cautionSeconds),
      warningThreshold(warningSeconds),
      dangerThreshold(dangerSeconds) {
}

TempResult HighTempExposure::update(
    float temperatureC,
    uint32_t nowSeconds
) {
    // 1. Validate sensor reading
    bool invalidReading =
        !std::isfinite(temperatureC) ||
        temperatureC < MIN_VALID_TEMP_C ||
        temperatureC > MAX_VALID_TEMP_C;

    bool errorChanged = (invalidReading != sensorErrorActive);
    sensorErrorActive = invalidReading;

    // 2. Detect measurement gaps and backward timestamps
    bool measurementGap = false;

    if (hasLastSample) {
        if (nowSeconds < lastUpdateSeconds ||
            nowSeconds - lastUpdateSeconds > MAX_SAMPLE_GAP_SECONDS) {
            measurementGap = true;
        }
    }

    if (measurementGap) {
        // Preserve the warning state, but interrupt timing.
        timingInterrupted = true;
        isRecovering = false;
    }

    // 3. Calculate cumulative exposure
    // Only valid consecutive samples within 5 seconds are counted.
    if (hasLastSample &&
        !invalidReading &&
        !measurementGap &&
        nowSeconds >= lastUpdateSeconds) {

        uint32_t elapsed = nowSeconds - lastUpdateSeconds;

        if (temperatureC >= 30.0f) {
            cumulativeExposureSeconds += elapsed;
        }
    }

    // Store the latest sample timestamp and validity
    lastUpdateSeconds = nowSeconds;
    hasLastSample = !invalidReading;

    // 4. Handle invalid sensor readings
    if (invalidReading) {
        // Keep the existing warning state.
        // Restart continuous timing after recovery.
        timingInterrupted = true;
        isRecovering = false;

        return {
            currentState,
            0,
            false,
            true,
            errorChanged,
            cumulativeExposureSeconds
        };
    }

    // 5. Restart continuous timing after a gap or sensor error
    if (timingInterrupted) {
        currentTempZone = TempState::NORMAL;
        zoneStartSeconds = nowSeconds;
        isRecovering = false;
        timingInterrupted = false;
    }

    // 6. Determine current temperature zone
    TempState newZone;

    if (temperatureC >= 35.0f) {
        newZone = TempState::DANGER;
    }
    else if (temperatureC >= 33.0f) {
        newZone = TempState::WARNING;
    }
    else if (temperatureC >= 30.0f) {
        newZone = TempState::CAUTION;
    }
    else {
        newZone = TempState::NORMAL;
    }

    // Reset continuous timer when the temperature zone changes
    if (newZone != currentTempZone) {
        currentTempZone = newZone;
        zoneStartSeconds = nowSeconds;
    }

    uint32_t exposureSeconds = 0;
    TempState newState = currentState;

    // 7. Handle recovery at normal temperature
    if (currentTempZone == TempState::NORMAL) {
        if (currentState != TempState::NORMAL) {
            if (!isRecovering) {
                isRecovering = true;
                recoveryStartSeconds = nowSeconds;
            }

            if (nowSeconds - recoveryStartSeconds >= recoveryThreshold) {
                newState = TempState::NORMAL;
                isRecovering = false;
            }
        }
        else {
            isRecovering = false;
        }
    }
    else {
        // 8. Calculate continuous exposure in current zone
        isRecovering = false;
        exposureSeconds = nowSeconds - zoneStartSeconds;

        TempState qualifiedState = TempState::NORMAL;

        if (currentTempZone == TempState::CAUTION &&
            exposureSeconds >= cautionThreshold) {
            qualifiedState = TempState::CAUTION;
        }

        if (currentTempZone == TempState::WARNING &&
            exposureSeconds >= warningThreshold) {
            qualifiedState = TempState::WARNING;
        }

        if (currentTempZone == TempState::DANGER &&
            exposureSeconds >= dangerThreshold) {
            qualifiedState = TempState::DANGER;
        }

        // Escalate warnings only.
        // Return to NORMAL after the recovery threshold.
        if (static_cast<int>(qualifiedState) >
            static_cast<int>(currentState)) {
            newState = qualifiedState;
        }
    }

    // 9. Update warning state
    bool stateChanged = (newState != currentState);
    currentState = newState;

    // 10. Return continuous time, cumulative time and sensor status
    return {
        currentState,
        exposureSeconds,
        stateChanged,
        false,
        errorChanged,
        cumulativeExposureSeconds
    };
}
