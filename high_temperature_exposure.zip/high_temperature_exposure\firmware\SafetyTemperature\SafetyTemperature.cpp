
#include "SafetyTemperature.h"
#include "high_temp_exposure.h"

#include "SinglePortModule.h"
#include "MeshService.h"
#include "Channels.h"
#include "main.h"

#include <Arduino.h>
#include <cstdio>
#include <cstring>

class SafetyTemperatureThread : public SinglePortModule,
                                private concurrency::OSThread {
private:
    HighTempExposure detector;

    // Send a JSON message over the configured private mesh channel.
    void sendJsonMessage(const char *message) {
        if (channels.isDefaultChannel(0)) {
            Serial.println(
                "[SafetyTemperature] Private channel required"
            );
            return;
        }

        meshtastic_MeshPacket *p = allocDataPacket();

        if (!p) {
            Serial.println(
                "[SafetyTemperature] Packet allocation failed"
            );
            return;
        }

        size_t length = strlen(message);

        if (length > sizeof(p->decoded.payload.bytes)) {
            Serial.println(
                "[SafetyTemperature] Payload too large"
            );
            packetPool.release(p);
            return;
        }

        p->want_ack = false;
        p->decoded.payload.size = length;

        memcpy(
            p->decoded.payload.bytes,
            message,
            length
        );

        ErrorCode result = service->sendToMesh(p);

        if (result == ERRNO_OK ||
            result == ERRNO_SHOULD_RELEASE) {
            Serial.println(
                "[SafetyTemperature] Message accepted for transmission"
            );
        } else {
            Serial.println(
                "[SafetyTemperature] Transmission request failed"
            );
        }
    }

    // Send an alert when the temperature warning state changes.
    void sendTemperatureAlert(
        TempState state,
        float temperatureC,
        uint32_t exposureSeconds,
        uint32_t cumulativeExposureSeconds
    ) {
        const char *stateName = nullptr;

        switch (state) {
            case TempState::NORMAL:
                stateName = "NORMAL";
                break;

            case TempState::CAUTION:
                stateName = "CAUTION";
                break;

            case TempState::WARNING:
                stateName = "WARNING";
                break;

            case TempState::DANGER:
                stateName = "DANGER";
                break;

            default:
                return;
        }

        char message[192];

        int length = snprintf(
            message,
            sizeof(message),
            "{\"event\":\"HIGH_TEMP_EXPOSURE\","
            "\"state\":\"%s\","
            "\"temperature_c\":%.1f,"
            "\"exposure_seconds\":%lu,"
            "\"cumulative_exposure_seconds\":%lu}",
            stateName,
            static_cast<double>(temperatureC),
            static_cast<unsigned long>(exposureSeconds),
            static_cast<unsigned long>(cumulativeExposureSeconds)
        );

        if (length < 0 ||
            static_cast<size_t>(length) >= sizeof(message)) {
            Serial.println(
                "[SafetyTemperature] Alert formatting failed"
            );
            return;
        }

        sendJsonMessage(message);
    }

    // Notify the gateway when sensor error status changes.
    void sendSensorStatus(bool sensorError) {
        char message[128];

        const char *status = sensorError
            ? "ERROR"
            : "RECOVERED";

        int length = snprintf(
            message,
            sizeof(message),
            "{\"event\":\"SENSOR_ERROR\","
            "\"sensor\":\"TEMPERATURE\","
            "\"status\":\"%s\"}",
            status
        );

        if (length < 0 ||
            static_cast<size_t>(length) >= sizeof(message)) {
            Serial.println(
                "[SafetyTemperature] Sensor status formatting failed"
            );
            return;
        }

        sendJsonMessage(message);
    }

public:
    SafetyTemperatureThread()
        : SinglePortModule(
              "SafetyTemperature",
              meshtastic_PortNum_TEXT_MESSAGE_APP
          ),
          concurrency::OSThread("SafetyTemperature"),
          detector() {
    }

protected:
    int32_t runOnce() override {
        uint32_t nowSeconds = millis() / 1000;

        // Simulated temperature for PC/firmware testing.
        // Replace with a real sensor reading after hardware arrives.
        float temperatureC = 36.0f;

        TempResult result = detector.update(
            temperatureC,
            nowSeconds
        );

        // Send sensor error/recovery only on status transitions.
        if (result.sensorErrorChanged) {
            sendSensorStatus(result.sensorError);
        }

        // Send temperature alert only when warning state changes.
        if (result.stateChanged) {
            Serial.println(
                "[SafetyTemperature] Warning state changed"
            );

            sendTemperatureAlert(
                result.state,
                temperatureC,
                result.exposureSeconds,
                result.cumulativeExposureSeconds
            );
        }

        return 1000;
    }
};

void setupSafetyTemperature() {
    new SafetyTemperatureThread();
}
