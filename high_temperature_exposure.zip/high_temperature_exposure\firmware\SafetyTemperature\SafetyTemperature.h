#pragma once

// Meshtastic 시작 시 고온 노출 감지 모듈 등록
void setupSafetyTemperature();