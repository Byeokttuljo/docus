
#include "high_temp_exposure.h"
#include <cassert>
#include <iostream>
#include <limits>

int main() {
    HighTempExposure detector(10, 5, 3);

    // First measurement: no elapsed time yet
    auto r = detector.update(28.0f, 0);
    assert(r.cumulativeExposureSeconds == 0);

    // High temperature for 3 seconds
    detector.update(31.0f, 1);
    r = detector.update(31.0f, 4);
    assert(r.cumulativeExposureSeconds == 4);
    std::cout << "[PASS] High temperature accumulated\n";

    // Normal temperature: cumulative time stays unchanged
    r = detector.update(28.0f, 5);
    assert(r.cumulativeExposureSeconds == 4);
    std::cout << "[PASS] Normal temperature pauses accumulation\n";

    // High temperature again: previous cumulative time retained
    r = detector.update(34.0f, 6);
    assert(r.cumulativeExposureSeconds == 5);
    std::cout << "[PASS] Repeated exposure accumulated\n";

    // Sensor error: do not count missing interval
    r = detector.update(
        std::numeric_limits<float>::quiet_NaN(), 7
    );
    assert(r.cumulativeExposureSeconds == 5);
    std::cout << "[PASS] Sensor error excluded\n";

    // First valid reading after error does not add elapsed time
    r = detector.update(36.0f, 8);
    assert(r.cumulativeExposureSeconds == 5);
    std::cout << "[PASS] Sensor recovery handled\n";

    // Gap longer than 5 seconds: do not count unknown interval
    r = detector.update(36.0f, 20);
    assert(r.cumulativeExposureSeconds == 5);
    std::cout << "[PASS] Long measurement gap excluded\n";

    std::cout << "\nAll cumulative exposure tests passed!\n";
    return 0;
}
