#ifndef HIGH_TEMP_EXPOSURE_H
#define HIGH_TEMP_EXPOSURE_H

#include <cstdint>

enum class TempState {
    NORMAL,
    CAUTION,
    WARNING,
    DANGER
};

struct TempResult {
    TempState state;
    uint32_t exposureSeconds;
    bool stateChanged;

    bool sensorError = false;
    bool sensorErrorChanged = false;
    uint32_t cumulativeExposureSeconds = 0;
};

class HighTempExposure {
private:

    uint32_t cumulativeExposureSeconds = 0;
    uint32_t lastUpdateSeconds = 0;
    bool hasLastSample = false;

    bool sensorErrorActive = false;
    bool timingInterrupted = false;
    
    TempState currentState;

    // 현재 온도 구간
    TempState currentTempZone;

    // 현재 온도 구간에 진입한 시간
    uint32_t zoneStartSeconds;

    // 위험 상태 해제를 위한 정상 온도 유지 시작시간
    uint32_t recoveryStartSeconds;

    // 정상 온도 유지 여부
    bool isRecovering;

    // 위험 상태 해제에 필요한 시간 (초)
    uint32_t recoveryThreshold = 5;

    // 온도 구간별 경고 발생 기준 (초)
    uint32_t cautionThreshold;
    uint32_t warningThreshold;
    uint32_t dangerThreshold;

public:
    // 기본값: CAUTION 600초, WARNING 300초, DANGER 60초
    HighTempExposure(
        uint32_t cautionSeconds = 600,
        uint32_t warningSeconds = 300,
        uint32_t dangerSeconds = 60
    );

    TempResult update(float temperatureC, uint32_t nowSeconds);
};

#endif