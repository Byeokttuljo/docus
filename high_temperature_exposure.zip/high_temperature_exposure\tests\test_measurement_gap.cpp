
#include "high_temp_exposure.h"
#include <cassert>
#include <iostream>

int main() {
    HighTempExposure detector(10, 5, 3);

    // 1. Start high-temperature exposure
    auto r = detector.update(36.0f, 0);
    assert(r.exposureSeconds == 0);
    assert(r.cumulativeExposureSeconds == 0);
    std::cout << "[PASS] Initial exposure started\n";

    // 2. Continuous exposure reaches DANGER
    r = detector.update(36.0f, 3);
    assert(r.exposureSeconds == 3);
    assert(r.cumulativeExposureSeconds == 3);
    assert(r.state == TempState::DANGER);
    std::cout << "[PASS] DANGER triggered after 3 seconds\n";

    // 3. Simulate a 20-second measurement gap
    r = detector.update(36.0f, 23);
    assert(r.exposureSeconds == 0);
    assert(r.cumulativeExposureSeconds == 3);
    assert(r.state == TempState::DANGER);
    std::cout << "[PASS] Measurement gap resets continuous time\n";
    std::cout << "[PASS] Cumulative time and warning retained\n";

    // 4. Valid measurements resume
    r = detector.update(36.0f, 24);
    assert(r.exposureSeconds == 1);
    assert(r.cumulativeExposureSeconds == 4);
    std::cout << "[PASS] Continuous timing restarted\n";

    std::cout << "\nAll measurement gap tests passed!\n";
    return 0;
}
