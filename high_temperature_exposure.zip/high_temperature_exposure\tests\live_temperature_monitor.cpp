
#include "high_temp_exposure.h"

#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <thread>
#include <vector>

using namespace std;

struct DemoStep {
    float temperature;
    uint32_t elapsedSeconds;
    string scenario;
};

string stateName(TempState state) {
    switch (state) {
        case TempState::NORMAL:  return "NORMAL";
        case TempState::CAUTION: return "CAUTION";
        case TempState::WARNING: return "WARNING";
        case TempState::DANGER:  return "DANGER";
    }
    return "UNKNOWN";
}

string temperatureText(float temperature) {
    if (!std::isfinite(temperature)) {
        return "INVALID";
    }

    return to_string(temperature).substr(0, 5);
}

int main() {
    // DEMO MODE: CAUTION 10s, WARNING 5s, DANGER 3s
    // Firmware defaults: 600s, 300s, 60s
    HighTempExposure detector(10, 5, 3);

    const float invalid = numeric_limits<float>::quiet_NaN();

    vector<DemoStep> steps;

    auto add = [&](float temp, int count, const string& scenario) {
        for (int i = 0; i < count; ++i) {
            steps.push_back({temp, 1, scenario});
        }
    };

    // 1. Normal temperature
    add(28.0f, 3, "Normal temperature");

    // 2. CAUTION after sustained exposure
    add(31.5f, 12, "CAUTION exposure");

    // 3. WARNING after sustained exposure
    add(34.0f, 7, "WARNING exposure");

    // 4. DANGER after sustained exposure
    add(36.0f, 5, "DANGER exposure");

    // 5. Recovery to NORMAL
    add(27.0f, 7, "Temperature recovery");

    // 6. Repeated exposure / cumulative time
    add(36.0f, 5, "Repeated high-temperature exposure");

    // 7. Sensor error and recovery
    add(invalid, 3, "Sensor error");
    add(36.0f, 5, "Sensor recovered");

    // 8. Measurement gap (> 5 seconds)
    steps.push_back({36.0f, 8, "Measurement gap (8 seconds)"});
    add(36.0f, 5, "Exposure after measurement gap");

    uint32_t nowSeconds = 0;
    TempState previousState = TempState::NORMAL;

    cout << "\n============================================\n";
    cout << "  HIGH TEMPERATURE EXPOSURE LIVE MONITOR\n";
    cout << "============================================\n";
    cout << "  MODE: PC SIMULATION (NO REAL SENSOR / LORA)\n";
    cout << "  DEMO THRESHOLDS: 10s / 5s / 3s\n";
    cout << "  FIRMWARE DEFAULTS: 600s / 300s / 60s\n";
    cout << "  RECOVERY: 5 seconds below 30 C\n";
    cout << "============================================\n\n";

    for (const auto& step : steps) {
        nowSeconds += step.elapsedSeconds;

        TempResult result = detector.update(
            step.temperature,
            nowSeconds
        );

        cout << fixed << setprecision(1);
        cout << "[T+" << setw(3) << nowSeconds << "s] "
             << "TEMP=" << setw(7) << temperatureText(step.temperature)
             << " | STATE=" << setw(7) << stateName(result.state)
             << " | CONT=" << setw(3) << result.exposureSeconds << "s"
             << " | TOTAL=" << setw(3)
             << result.cumulativeExposureSeconds << "s"
             << " | SENSOR=" << (result.sensorError ? "ERROR" : "OK")
             << " | " << step.scenario << "\n";

        if (result.stateChanged) {
            cout << "    >>> [HIGH_TEMP_EXPOSURE] "
                 << stateName(previousState)
                 << " -> " << stateName(result.state)
                 << "\n";
        }

        if (result.sensorErrorChanged) {
            cout << "    >>> [SENSOR_ERROR] "
                 << (result.sensorError ? "ERROR" : "RECOVERED")
                 << "\n";
        }

        if (step.elapsedSeconds > 5) {
            cout << "    >>> [MEASUREMENT_GAP] "
                 << step.elapsedSeconds
                 << " seconds without a sample\n";
        }

        previousState = result.state;

        cout.flush();
        this_thread::sleep_for(chrono::seconds(1));
    }

    cout << "\n============================================\n";
    cout << "  LIVE SIMULATION COMPLETED\n";
    cout << "============================================\n";

    return 0;
}
